import UIKit

var greeting = "Hello, playground"
print("Hello");
print("welcome to NWMSU")
